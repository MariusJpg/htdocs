<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>oppg5</title>
</head>
<body>
    <form action ="Op.php" method ="POST">


        <input type = "text" name = "Biltype"> Biltype<br>
        <input type = "text" name = "Co2"> Co2 pr mil<br>
        <input type = "text" name = "Lengde"> Kjørelengde i km<br>
        <input type = "text" name = "Ar"> År du vil beholde den<br>

        <input type="submit" value="submit"> 


    
    
 

    </form>
    
    
</body>
</html>


