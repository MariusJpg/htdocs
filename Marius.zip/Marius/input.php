<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>oppg8</title>
</head>
<body>
    <form action ="resultat.php" method ="POST">


        <input type = "text" name = "tall1"> Tall nummer 1<br>
        <input type = "text" name = "tall2"> Tall nummer 2<br>

        <input type="radio" name="Op" value="Pluss"> Pluss <br>
        <input type="radio" name="Op" value="Minus"> Minus <br>
        <input type="radio" name="Op" value="Gange"> Gange <br>
        <input type="radio" name="Op" value="Dele"> Dele <br>
        <input type="radio" name="Op" value="Opphøyd"> Opphøyd <br>

        <input type="submit" value="submit"> 


    
    
 

    </form>
    
    
</body>
</html>


